class Service {
  static const url = "https://taxi-segurito.000webhostapp.com/flutter_api/";
}
