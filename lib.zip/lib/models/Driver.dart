class Driver {
  String name;
  String dni;
  String phone;
  Driver(this.name, this.dni, this.phone);
}
