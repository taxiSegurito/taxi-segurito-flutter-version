class User {
  // faltan definir algunos atributos
  String username;
  String password;

  User(this.username, this.password);
}
